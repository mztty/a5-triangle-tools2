package triangle.abstractMachine;

public enum Register {
	CB, CT, PB, PT, SB, ST, HB, HT, LB, L1, L2, L3, L4, L5, L6, CP
}
