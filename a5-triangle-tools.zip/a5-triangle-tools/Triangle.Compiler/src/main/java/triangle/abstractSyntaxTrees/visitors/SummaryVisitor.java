package triangle.abstractSyntaxTrees.visitors;

import triangle.abstractSyntaxTrees.Program;
import triangle.abstractSyntaxTrees.commands.*;
import triangle.abstractSyntaxTrees.expressions.*;

public class SummaryVisitor implements ProgramVisitor<Void, Void>, CommandVisitor<Void, Void>, ExpressionVisitor<Void, Void> {

	//counters
    private int binaryExpressionCount = 0;
    private int ifCommandCount = 0;
    private int whileCommandCount = 0;

    //visiting command
    @Override
    public Void visitProgram(Program ast, Void arg) {
        ast.C.visit(this);
        return null;
    }

    //visiting ifcommand
    @Override
    public Void visitIfCommand(IfCommand ast, Void arg) {
        ifCommandCount++;
        return null;
    }

    //visiting whilecommand
    @Override
    public Void visitWhileCommand(WhileCommand ast, Void arg) {
        whileCommandCount++;
        return null;
    }

    //visit binaryexpression node
    @Override
    public Void visitBinaryExpression(BinaryExpression ast, Void arg) {
        binaryExpressionCount++;
        return null;
    }

    //summary
    public String getSummary() {
        return "### summary ###\n"+
               "binary expressions  "+binaryExpressionCount+"\n"+
               "if commands  "+ifCommandCount+"\n"+
               "while commands  "+whileCommandCount+"\n"+
               "###############";
    }

    // required because java is stupid
    @Override public Void visitAssignCommand(AssignCommand ast, Void arg) { return null; }
    @Override public Void visitCallCommand(CallCommand ast, Void arg) { return null; }
    @Override public Void visitEmptyCommand(EmptyCommand ast, Void arg) { return null; }
    @Override public Void visitLetCommand(LetCommand ast, Void arg) { return null; }
    @Override public Void visitSequentialCommand(SequentialCommand ast, Void arg) { return null; }
    @Override public Void visitIntegerExpression(IntegerExpression ast, Void arg) { return null; }
    @Override public Void visitCallExpression(CallExpression ast, Void arg) { return null; }
    @Override public Void visitRecordExpression(RecordExpression ast, Void arg) { return null; }
    @Override public Void visitArrayExpression(ArrayExpression ast, Void arg) { return null; }
    @Override public Void visitCharacterExpression(CharacterExpression ast, Void arg) { return null; }
    @Override public Void visitEmptyExpression(EmptyExpression ast, Void arg) { return null; }
    @Override public Void visitLetExpression(LetExpression ast, Void arg) { return null; }
    @Override public Void visitUnaryExpression(UnaryExpression ast, Void arg) { return null; }
    @Override public Void visitVnameExpression(VnameExpression ast, Void arg) { return null; }
	@Override public Void visitIfExpression(IfExpression ast, Void arg) {// TODO Auto-generated method stub
		return null;
	}

	@Override
	public Void visitLoopWhileDoCommand(LoopWhileDoCommand ast, Void arg) {
		// TODO Auto-generated method stub
		return null;
	}
}
