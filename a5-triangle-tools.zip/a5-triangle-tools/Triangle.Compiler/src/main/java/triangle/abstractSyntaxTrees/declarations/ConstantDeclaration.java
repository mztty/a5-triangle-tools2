package triangle.abstractSyntaxTrees.declarations;

import triangle.abstractSyntaxTrees.types.TypeDenoter;

public interface ConstantDeclaration {

	TypeDenoter getType();
	
}
